import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-inventos',
  templateUrl: './inventos.component.html',
  styleUrls: ['./inventos.component.css']
})
export class InventosComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
