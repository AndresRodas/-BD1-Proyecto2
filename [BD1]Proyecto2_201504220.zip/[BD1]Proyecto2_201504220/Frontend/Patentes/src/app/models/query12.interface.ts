export interface Query12{ 

}