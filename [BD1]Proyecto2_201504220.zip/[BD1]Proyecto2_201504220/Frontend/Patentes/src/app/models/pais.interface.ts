export interface Pais{ 
    id: number,
    nombre: string,
    poblacion: number, 
    area: number,
    capital: string,
    id_region: number
}