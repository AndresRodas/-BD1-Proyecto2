export interface Query20{ 
    nombre: string,
    salario: number,
    comision: number
}