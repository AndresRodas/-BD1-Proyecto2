export interface Query1{ 
    profesional: string,
    inventos: number
}