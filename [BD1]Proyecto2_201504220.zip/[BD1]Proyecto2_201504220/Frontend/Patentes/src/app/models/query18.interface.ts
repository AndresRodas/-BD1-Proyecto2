export interface Query18{ 
    pais: string,
    poblacion: number
}