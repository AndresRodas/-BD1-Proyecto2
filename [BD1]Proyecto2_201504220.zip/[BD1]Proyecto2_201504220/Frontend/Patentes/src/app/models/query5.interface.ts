export interface Query5{ 
    area: string,
    profesional: string,
    salario: number
}