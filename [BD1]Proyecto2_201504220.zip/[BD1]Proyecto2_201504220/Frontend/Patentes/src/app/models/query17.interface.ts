export interface Query17{ 
    invento: string,
    anio: number
}