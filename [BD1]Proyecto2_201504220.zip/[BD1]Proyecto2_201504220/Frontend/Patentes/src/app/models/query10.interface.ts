export interface Query10{ 
    inventor: string,
    invento: string,
    anio: number
}