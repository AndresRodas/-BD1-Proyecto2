export interface Query16{ 
    profesional: string,
    area: string
}