export interface Query8{ 
    inicial: string,
    area: number
}