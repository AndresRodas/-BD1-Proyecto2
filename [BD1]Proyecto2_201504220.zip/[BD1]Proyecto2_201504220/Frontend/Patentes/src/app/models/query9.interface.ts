export interface Query9{ 
    inventor: string,
    invento: string
}