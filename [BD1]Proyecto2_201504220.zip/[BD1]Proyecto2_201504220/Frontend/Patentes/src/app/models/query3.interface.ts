export interface Query3{ 
    area: string,
    pais: string
}