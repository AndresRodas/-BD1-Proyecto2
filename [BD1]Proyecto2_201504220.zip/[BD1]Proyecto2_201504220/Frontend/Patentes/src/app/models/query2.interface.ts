export interface Query2{ 
    continente: string,
    pais: number
    respuestas: number
}