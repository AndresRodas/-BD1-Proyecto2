export interface Query4{ 
    jefe: string,
    profesional: string,
    area: string
}