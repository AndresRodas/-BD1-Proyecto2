export interface Query19{ 
    pais: string,
    frontera: string
}