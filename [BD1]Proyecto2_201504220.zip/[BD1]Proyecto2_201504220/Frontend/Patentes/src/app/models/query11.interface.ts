export interface Query11{
    pais: string,
    area: number,
    fronteras: number
}