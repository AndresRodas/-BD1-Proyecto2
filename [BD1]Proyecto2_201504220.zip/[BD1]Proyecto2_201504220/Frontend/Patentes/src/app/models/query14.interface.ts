export interface Query14{ 
    encuesta: string,
    paises: number
}