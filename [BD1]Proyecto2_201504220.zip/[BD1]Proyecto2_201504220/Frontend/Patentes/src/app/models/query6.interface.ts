export interface Query6{ 
    nombre: string,
    aciertos: number
}