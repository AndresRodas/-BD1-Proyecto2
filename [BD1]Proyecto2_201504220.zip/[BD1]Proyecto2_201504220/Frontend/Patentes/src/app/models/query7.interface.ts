export interface Query7{ 
    invento: string
}