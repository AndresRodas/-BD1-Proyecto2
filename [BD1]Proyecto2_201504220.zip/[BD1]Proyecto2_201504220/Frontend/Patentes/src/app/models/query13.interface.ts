export interface Query13{ 
    nombre: string,
    salario: number,
    comision: number,
    sueldo: number
}