export interface Query15{ 
    pais: string,
    poblacion: number,
    poblacion_centroamerica: number
}